package com.salfit;

class Main {
    public static void main(String[] args)
    {
        System.out.println("Witaj w naszym projekcie!");
    }
}